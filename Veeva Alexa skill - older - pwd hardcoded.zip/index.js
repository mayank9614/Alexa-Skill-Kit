/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/
/**
 * This sample demonstrates a simple skill built with the Amazon Alexa Skills
 * nodejs skill development kit.
 * This sample supports multiple lauguages. (en-US, en-GB, de-DE).
 * The Intent Schema, Custom Slots and Sample Utterances for this skill, as well
 * as testing instructions are located at https://github.com/alexa/skill-sample-nodejs-fact
 **/

'use strict';
const Alexa = require('alexa-sdk');
const request = require('request');

//=========================================================================================================================================
//TODO: The items below this comment need your attention.
//=========================================================================================================================================

//Replace with your app ID (OPTIONAL).  You can find this value at the top of your skill's page on http://developer.amazon.com.
//Make sure to enclose your value in quotes, like this: const APP_ID = 'amzn1.ask.skill.bb4045e6-b3e8-4133-b650-72923c5980f1';
const APP_ID = 'amzn1.ask.skill.0f0c6dce-cba3-442e-ba2b-de14297bf0e7';

const SKILL_NAME = 'Alexa Skill';
const GET_FACT_MESSAGE = "Here's your fact: ";
const HELP_MESSAGE = 'You can say tell me a space fact, or, you can say exit... What can I help you with?';
const HELP_REPROMPT = 'What can I help you with?';
const STOP_MESSAGE = 'Goodbye!';
var accessToken = 'Please try again';
var accountNameMIRF = 'Please provide the account name';
var accName = 'Account Name not specified. Please try again.';
var firstCall = 'true';
var interactionId = "";

//=========================================================================================================================================
//TODO: Replace this data with your own.  You can find translations of this data at http://github.com/alexa/skill-sample-node-js-fact/data
//=========================================================================================================================================
const data = [
    'A year on Mercury is just 88 days long.',
    'Despite being farther from the Sun, Venus experiences higher temperatures than Mercury.',
    'Venus rotates counter-clockwise, possibly because of a collision in the past with an asteroid.',
    'On Mars, the Sun appears about half the size as it does on Earth.',
    'Earth is the only planet not named after a god.',
    'Jupiter has the shortest day of all the planets.',
    'The Milky Way galaxy will collide with the Andromeda Galaxy in about 5 billion years.',
    'The Sun contains 99.86% of the mass in the Solar System.',
    'The Sun is an almost perfect sphere.',
    'A total solar eclipse can happen once every 1 to 2 years. This makes them a rare event.',
    'Saturn radiates two and a half times more energy into space than it receives from the sun.',
    'The temperature inside the Sun can reach 15 million degrees Celsius.',
    'The Moon is moving approximately 3.8 cm away from our planet every year.',
];

//=========================================================================================================================================
//Editing anything below this line might break your skill.
//=========================================================================================================================================

const handlers = {

    'LaunchRequest': function () {

        console.log('Here');
        this.emit('GetNewFactIntent');
    },

    'Unhandled': function() {
      this.emit(':ask', 'Hmm I am not sure. Can you please provide me more details.');
    },

    'GetNewFactIntent': function () {
      var self = this;
      var options = { method: 'POST',
        url: 'https://test.salesforce.com/services/oauth2/token',
        qs:
          { grant_type: 'password',
            client_id: '3MVG9jfQT7vUue.E.P52tI6SA1V9dIJIAgeNETQ58N2M5rIcdGz770jUW3FOGB9HzO7c.sTmgAGTDRIJRaK6S',
            client_secret: '6204642329457328092',
            username: 'aditya.sridhara.rao@accenture.dev.lsassets',
            password: 'Baxter@1986' },
            headers:
              { 'postman-token': 'dd5d54f4-ecb5-f886-25f0-6b6b17d0d999',
              'cache-control': 'no-cache' },
            json: true
          };

          request(options, function (error, response, body) {
            if (error) throw new Error(error);

            //body=JSON.parse(body);
            console.log(body);
            accessToken = body.access_token;
            console.log(accessToken);
            self.emit(':ask', 'Hi! Welcome to Veeva. How may I help you?');
            //self.emit(':tell', 'PlannedInteractions');
          });
    },


    'PlannedInteractions': function () {
      var self = this;
      var alexaAnnounce = 'There are no planned calls.';
      var options = { method: 'POST',
        url: 'https://cs52.salesforce.com/services/apexrest/interaction_details/',
        headers:
          { 'postman-token': '79f01a72-ea2f-cf68-0f82-93b3af320e38',
            'cache-control': 'no-cache',
            authorization: 'OAuth '+accessToken,
                'content-type': 'application/json' },
        body:
          { userName: 'aditya.sridhara.rao@accenture.dev.lsassets',
            dateOfInteraction: this.event.request.intent.slots.Date.value
          },
       json: true
      };
      request(options, function (error, response, body) {
        console.log(alexaAnnounce);
        console.log(alexaAnnounce);
        if (error) throw new Error(error);

        body=JSON.parse(body);
        console.log(body+' and at last '+body.length);

        //body[0].Account_vod__r.Name+
        for(var i = 0; i< body.length; i++){
          if(body.length === 1){
            var dateString=format_time(body[i].Call_Datetime_vod__c);

            if(!body[i].hasOwnProperty('Address_vod__c')){
                alexaAnnounce = 'You have only one planned call with '+body[i].Account_vod__r.Name+' at '+dateString+'<break time="2s"/> Do you need more details of the previous calls with any of these doctors.';
            }else{
                alexaAnnounce = 'You have only one planned call with '+body[i].Account_vod__r.Name+' at '+dateString+' in '+body[i].Address_vod__c+'<break time="2s"/> Do you need more details of the previous calls with any of these doctors.';
            }
          }else if(i === 0){

            //var dateString = new Date(body[i].Call_Datetime_vod__c);
            //dateString = dateString.split(' ').slice(4, 5).join(' ');
            var dateString=format_time(body[i].Call_Datetime_vod__c);
            console.log('date idhar h, tera dhyan kidhar h '+ dateString);
            //console.log('idhar hi mere bhai '+ format_time(body[i].Call_Datetime_vod__c));

            if(!body[i].hasOwnProperty('Address_vod__c')){
                alexaAnnounce = 'Your first call is with '+body[i].Account_vod__r.Name+' at '+dateString+'<break time="2s"/>';
            }else{
                alexaAnnounce = 'Your first call is with '+body[i].Account_vod__r.Name+' at '+dateString+' in '+body[i].Address_vod__c+'<break time="2s"/>';
            }
          }else if(i === (body.length-1)){
            var dateString=format_time(body[i].Call_Datetime_vod__c);

            if(!body[i].hasOwnProperty('Address_vod__c')){
                console.log('inside if last call');
                alexaAnnounce = alexaAnnounce+' Your last call is with '+body[i].Account_vod__r.Name+' at '+dateString+'<break time="2s"/> Do you need more details of the previous calls with any of these doctors.';
            }else{
                console.log('inside if last call else part');
                alexaAnnounce = alexaAnnounce+' Your last call is with '+body[i].Account_vod__r.Name+' at '+dateString+' in '+body[i].Address_vod__c+'<break time="2s"/> Do you need more details of the previous calls with any of these doctors.';
            }
          }else if(body.length === 0){
            alexaAnnounce = 'There are no planned calls';
          }
          else{
            var dateString=format_time(body[i].Call_Datetime_vod__c);

            if(!body[i].hasOwnProperty('Address_vod__c')){
                alexaAnnounce = alexaAnnounce+' Your next call is with '+body[i].Account_vod__r.Name+' at '+dateString+'<break time="2s"/>';
            }else{
                alexaAnnounce = alexaAnnounce+' Your next call is with '+body[i].Account_vod__r.Name+' at '+dateString+' in '+body[i].Address_vod__c+'<break time="2s"/>';
            }
          }
        }
        self.emit(':ask', alexaAnnounce);
      })
    },

    'PreviousInteractionDetails': function () {
      if (this.event.request.dialogState !== "COMPLETED") {
          // this.emit(":delegate", updatedIntent);
          this.emit(":delegate");
      }else{
        var self = this;
        var alexaAnnounce = "There are no previous calls with the mentioned doctor.";
        var products="The product discussed were ";
        var options = { method: 'POST',
          url: 'https://cs52.salesforce.com/services/apexrest/interaction_details/',
          headers:
            { 'postman-token': '7389a218-8278-15af-071a-82e5ca6942b4',
              'cache-control': 'no-cache',
              authorization: 'OAuth '+accessToken,
              'content-type': 'application/json' },
          body:
          {
           "userName" : "aditya.sridhara.rao@accenture.dev.lsassets",
           "accountName" : this.event.request.intent.slots.accountName.value
          },
         json: true
        };
        accountNameMIRF = this.event.request.intent.slots.accountName.value;
        console.log('Account Name for MIRF '+accountNameMIRF);
        request(options, function (error, response, body) {
          if (error) throw new Error(error);
          body=JSON.parse(body);
        //  console.log('here '+ body[0].Address_vod__c);

          console.log(body+' and at last PreviousIntractionDetails'+body.length);

          if(!body.length){
            alexaAnnounce == "There are no previous calls with this doctor.";
          }else{
            var detailedProducts = body[0].Detailed_Products_vod__c.split('  ');
            console.log('detailed product length '+ detailedProducts.length);

          if(!body[0].hasOwnProperty('Medical_Inquiry_vod__c')){
            var date = new Date(body[0].Call_Datetime_vod__c).toUTCString();
            date = date.split(' ').slice(0, 4).join(' ');
            var dateString=format_time(body[0].Call_Datetime_vod__c);
            if(body[0].Attendees_vod__c === 0){
              alexaAnnounce = 'You met '+body[0].Account_vod__r.Name+' on '+date+' at '+dateString+' It was a '+body[0].Call_Type_vod__c+' call. ';

              for(var i=0;i<detailedProducts.length;i++){
                if(i === (detailedProducts.length-2)){
                  products = products+detailedProducts[i]+' and ';
                }else if(i === (detailedProducts.length-1)){
                  products = products+detailedProducts[i];
                }else{
                  products = products+' '+detailedProducts[i]+', ';
                }
              }
              if(!body[0].hasOwnProperty('Call2_Key_Message_vod__r')){
                alexaAnnounce= alexaAnnounce+products+'.';
              }else{
                alexaAnnounce= alexaAnnounce+products+'. The media that was used during the interaction was '+body[0].Call2_Key_Message_vod__r.records[0].Clm_Presentation_Name_vod__c+'. ';
              }
            }
            else{
              alexaAnnounce = 'You met '+body[0].Account_vod__r.Name+' on '+date+' at '+dateString+' along with '+body[0].Attendees_vod__c+' attendees.'+' It was a '+body[0].Call_Type_vod__c+' call. ';

              for(var i=0;i<detailedProducts.length;i++){
                if(i === (detailedProducts.length-2)){
                  products = products+detailedProducts[i]+' and ';
                }else if(i === (detailedProducts.length-1)){
                  products = products+detailedProducts[i];
                }else{
                  products = products+' '+detailedProducts[i]+', ';
                }
              }
              if(!body[0].hasOwnProperty('Call2_Key_Message_vod__r')){
                alexaAnnounce= alexaAnnounce+products+'.';
              }else{
                alexaAnnounce= alexaAnnounce+products+'. The media that was used during the interaction was '+body[0].Call2_Key_Message_vod__r.records[0].Clm_Presentation_Name_vod__c+'. ';
              }
            }
          }else{
            var date = new Date(body[0].Call_Datetime_vod__c).toUTCString();
            date = date.split(' ').slice(0, 4).join(' ');
            var dateString=format_time(body[0].Call_Datetime_vod__c);

            if(body[0].Attendees_vod__c === 0){
              alexaAnnounce = 'You met '+body[0].Account_vod__r.Name+' on '+date+' at '+dateString+' It was a '+body[0].Call_Type_vod__c+' call. ';

              for(var i=0;i<detailedProducts.length;i++){
                if(i === (detailedProducts.length-2)){
                  products = products+detailedProducts[i]+' and ';
                }else if(i === (detailedProducts.length-1)){
                  products = products+detailedProducts[i];
                }else{
                  products = products+' '+detailedProducts[i]+', ';
                }
              }
              if(!body[0].hasOwnProperty('Call2_Key_Message_vod__r')){
                alexaAnnounce= alexaAnnounce+products+'. A MIRF was also raised during this call. Do you need more details about the last MIRF?';
              }else{
                alexaAnnounce= alexaAnnounce+products+'. The media that was used during the interaction was '+body[0].Call2_Key_Message_vod__r.records[0].Clm_Presentation_Name_vod__c+'. A MIRF was also raised during this call. Do you need more details about the last MIRF?';
              }
            }
            else{
              alexaAnnounce = 'You met '+body[0].Account_vod__r.Name+' on '+date+' at '+dateString+' along with '+body[0].Attendees_vod__c+' attendees.'+' It was a '+body[0].Call_Type_vod__c+' call. ';

              for(var i=0;i<detailedProducts.length;i++){
                if(i === (detailedProducts.length-2)){
                  products = products+detailedProducts[i]+' and ';
                }else if(i === (detailedProducts.length-1)){
                  products = products+detailedProducts[i];
                }else{
                  products = products+' '+detailedProducts[i]+', ';
                }
              }
              if(!body[0].hasOwnProperty('Call2_Key_Message_vod__r')){
                alexaAnnounce= alexaAnnounce+products+'. A MIRF was also raised during this call. Do you need more details about the last MIRF?';
              }else{
                alexaAnnounce= alexaAnnounce+products+'. The media that was used during the interaction was '+body[0].Call2_Key_Message_vod__r.records[0].Clm_Presentation_Name_vod__c+'. A MIRF was also raised during this call. Do you need more details about the last MIRF?';
              }
            }
          }
        }
          self.emit(':ask', alexaAnnounce);
        })
      }
    },

    'MirfDetails': function () {
      var self = this;
      var options = { method: 'POST',
        url: 'https://cs52.salesforce.com/services/apexrest/interaction_details/',
        headers:
        { 'postman-token': '14012c9d-8725-f97c-c5dc-bfe072720382',
          'cache-control': 'no-cache',
          'content-type': 'application/json',
          authorization: 'OAuth '+accessToken
        },
        body:{
          "userName" : "aditya.sridhara.rao@accenture.dev.lsassets",
          "accountName" : accountNameMIRF,
          "isMirfdetailsRequired" : "true"
        },
        json: true
      };

      request(options, function (error, response, body) {
        if (error) throw new Error(error);

        body=JSON.parse(body);
        console.log(body);

        if(body.length === 0){
          self.emit(':ask', 'There are no MIRFs for the mentioned doctor.');
        }else{
          self.emit(':ask', 'The Inquiry was regarding '+body[0].Medical_Inquiries_vod__r.records[0].Inquiry_Text__c+' and its status is '+ body[0].Medical_Inquiries_vod__r.records[0].Status_vod__c.split('_')[0]);
        }
      });
    },


    /*'PlannedInteractionsDesiredInfo': function () {
      var self = this;
      var alexaAnnounce = 'There are no planned calls.';
      var options = { method: 'POST',
        url: 'https://cs52.salesforce.com/services/apexrest/interaction_details/',
        headers:
          { 'postman-token': '79f01a72-ea2f-cf68-0f82-93b3af320e38',
            'cache-control': 'no-cache',
            authorization: 'OAuth '+accessToken,
                'content-type': 'application/json' },
        body:
          { userName: 'aditya.sridhara.rao@accenture.dev.lsassets',
            dateOfInteraction: this.event.request.intent.slots.Date.value
          },
       json: true
      };
      request(options, function (error, response, body) {
        console.log(alexaAnnounce);
        if (error) throw new Error(error);

        body=JSON.parse(body);
        console.log(body+' and at last '+body.length);
      }
    },*/

    'PreviousInteractionDesiredInfo': function () {
      var self = this;
      var alexaAnnounce = "There are no previous calls with this doctor.";
      var products = " ";
      var desiredInfo = this.event.request.intent.slots.lastcalldetails.value;

      if(firstCall === 'true'){
        accName = this.event.request.intent.slots.accountName.value;
        isFirstCall();
        console.log('Account Name in desired info 1'+ accName);
        console.log('firstCall in desired info 1'+ firstCall);
      }else if(firstCall === 'false' && (this.event.request.intent.slots.accountName.value)){
        accName = this.event.request.intent.slots.accountName.value;
        console.log('Account Name in desired info 2'+ accName);
        console.log('Account Name in desired info 2'+ firstCall);
      }else{
        accName = accName;
        console.log('Account Name in desired info 2'+ accName);
        console.log('Account Name in desired info 2'+ firstCall);
      }
      console.log('Account Name in desired info '+ accName);
      //lastcalldetails
      var options = { method: 'POST',
        url: 'https://cs52.salesforce.com/services/apexrest/interaction_details/',
        headers:
          { 'postman-token': '7389a218-8278-15af-071a-82e5ca6942b4',
            'cache-control': 'no-cache',
            authorization: 'OAuth '+accessToken,
            'content-type': 'application/json' },
        body:
        {
         "userName" : "aditya.sridhara.rao@accenture.dev.lsassets",
         "accountName" : accName
        },
       json: true
      };
      accountNameMIRF = this.event.request.intent.slots.accountName.value;
      request(options, function (error, response, body) {
        if (error) throw new Error(error);

        body=JSON.parse(body);
        console.log(body);
        console.log('slot value '+ desiredInfo);
        if(!body.length){
          console.log('body as null');
          alexaAnnounce = 'No records found for this doctor. Can you please try again with a different doctor?';
        }else{
          console.log('body not null');
            if(desiredInfo === 'products'){
              var detailedProducts = body[0].Detailed_Products_vod__c.split('  ');

              if(detailedProducts == 1){
                alexaAnnounce = 'The product discussed in the last call with '+body[0].Account_vod__r.Name+' was';
              }else{
                alexaAnnounce = 'The products discussed in the last call with '+body[0].Account_vod__r.Name+' were';
              }

              for(var i=0;i<detailedProducts.length;i++){
                if(i === (detailedProducts.length-2)){
                  products = products+detailedProducts[i]+' and ';
                }else if(i === (detailedProducts.length-1)){
                  products = products+detailedProducts[i];
                }else{
                  products = products+' '+detailedProducts[i]+', ';
                }
              }
              alexaAnnounce = alexaAnnounce+products;
            }else if(desiredInfo === 'when'){

              var date = new Date(body[0].Call_Datetime_vod__c).toUTCString();
              date = date.split(' ').slice(0, 4).join(' ');
              var dateString=format_time(body[0].Call_Datetime_vod__c);
              alexaAnnounce = 'You met '+body[0].Account_vod__r.Name+' on '+date+' at '+dateString+'.';

            }else if(desiredInfo === 'type'){
              alexaAnnounce = 'Your last call with '+body[0].Account_vod__r.Name+' was a '+body[0].Call_Type_vod__c+' call';
            }else if(desiredInfo === 'media'){
              alexaAnnounce = 'The media used was '+body[0].Call2_Key_Message_vod__r.records[0].Clm_Presentation_Name_vod__c+'.'
            }else if(desiredInfo === 'MIRF' || desiredInfo === 'mirf'){
              console.log('yes please');
              if(!body[0].hasOwnProperty('Medical_Inquiry_vod__c')){
                alexaAnnounce = 'There were no MIRFs recorded in the last call.'
              }else{
                alexaAnnounce = 'Yes a MIRF was raised during the last interaction. Do you need more details about the last MIRF?'
              }
            }
        }
        self.emit(':ask', alexaAnnounce);
      });
    },

    'AlertDetails': function () {
      var self = this;
      var alexaAnnounce = "";
      var options = {
        method: 'POST',
        url: 'https://cs52.salesforce.com/services/apexrest/alertdetails/',
        headers:
          { 'postman-token': '3e1e04f5-6f2d-1603-6844-a1871e58a71c',
            'cache-control': 'no-cache',
            'content-type': 'application/json',
            authorization: 'OAuth '+accessToken
          },
        body: {"userName" : "aditya.sridhara.rao@accenture.dev.lsassets"},
        json: true
      };

      request(options, function (error, response, body) {
        if (error) throw new Error(error);

        body=JSON.parse(body);
        console.log(body);
        if(!body.length){
          console.log('body as null');
          alexaAnnounce = 'There are no alerts for you at present.';
        }else{
          for(var i = 0; i< body.length; i++){
            //var dateString=format_time(body[i].Call_Datetime_vod__c);
            //var activationDate = new Date(body[i].Activation_Date_vod__c).toUTCString().split(' ').slice(0, 4).join(' ');
            //date = date.split(' ').slice(0, 4).join(' ');
            alexaAnnounce = alexaAnnounce+body[i].Alert_Text_vod__c+' .The Priority of the alert is '+body[i].Priority_vod__c+' .It was activated on '+new Date(body[i].Activation_Date_vod__c).toUTCString().split(' ').slice(0, 4).join(' ')+' at '+format_time(body[i].Activation_Date_vod__c)+' and will be expired on '+new Date(body[i].Expiration_Date_vod__c).toUTCString().split(' ').slice(0, 4).join(' ')+' at '+format_time(body[i].Expiration_Date_vod__c);
          }
          alexaAnnounce = alexaAnnounce+' Do you want to know about any add or drop in your territory?'
        }
        self.emit(':ask', alexaAnnounce);
      });
    },


    'TerritoryAddDropDetails': function () {
      var self = this;
      var alexaAnnounce = "There are no territory adds or drops for you at present.";
      var territoryAdds = "";
      var territoryDrops = "";

      var options = { method: 'POST',
        url: 'https://cs52.salesforce.com/services/apexrest/alertdetails/',
        headers:
        { 'postman-token': '534691d3-e522-c14b-9ccc-a2426320e4a7',
           'cache-control': 'no-cache',
           'content-type': 'application/json',
           authorization: 'OAuth '+accessToken
        },
        body: {"userName" : "aditya.sridhara.rao@accenture.dev.lsassets",
               "isTerritorydetailsRequired" : "true"
        },
        json: true
      };

      request(options, function (error, response, body) {
        if (error) throw new Error(error);

        body=JSON.parse(body);
        console.log(body);
        if(body.length){
            for(var i = 0; i< body.length; i++){
              if(!body[i].IsDeleted){
                //console.log(body[i].keys());
                console.log('Created Date please '+ body[i].CreatedDate+' '+body[i].IsDeleted);
                territoryAdds = territoryAdds+'<break time="1s"/>'+body[i].Account_vod__r.Name+" on "+new Date(body[i].CreatedDate).toUTCString().split(' ').slice(0, 4).join(' ')+' at '+format_time(body[i].CreatedDate);
              }else{
                //console.log(body[i].keys());
                console.log('Created Date please '+ body[i].LastModifiedDate +' '+body[i].IsDeleted);
                territoryDrops = territoryDrops+'<break time="1s"/>'+body[i].Account_vod__r.Name+" on "+new Date(body[i].LastModifiedDate).toUTCString().split(' ').slice(0, 4).join(' ')+' at '+format_time(body[i].LastModifiedDate);
              }
            }
          if(territoryAdds !== ""){
            console.log('added here');
            territoryAdds = 'The following Accounts were added <break time="1s"/>'+territoryAdds;
          }
          if(territoryDrops !== ""){
            console.log('dropped here');
            territoryDrops = 'The following Accounts were droped <break time="1s"/>'+territoryDrops;
          }
          alexaAnnounce = territoryAdds+'<break time="1s"/>'+territoryDrops;
        }
        self.emit(':ask', alexaAnnounce);
      });
    },

    'AlertDetailsDesiredInfo': function () {
      var self = this;
      var alexaAnnounce = "";
      var desiredInfo = this.event.request.intent.slots.alertSpecificDetail.value;
      var options = { method: 'POST',
        url: 'https://cs52.salesforce.com/services/apexrest/alertdetails/',
        headers:
         { 'postman-token': 'c9451912-3bed-ce6f-846e-4ff460338c3f',
           'cache-control': 'no-cache',
           'content-type': 'application/json',
           authorization: 'OAuth '+accessToken
         },
        body: {"userName" : "aditya.sridhara.rao@accenture.dev.lsassets"},
        json: true
      };

      request(options, function (error, response, body) {
        if (error) throw new Error(error);

        console.log('hi i am here');
        body=JSON.parse(body);
        console.log(body);

        if(!body.length){
          console.log('hi i am here1');
          alexaAnnounce = 'There are no alerts for you at present.';
        }else{
          for(var i=0;i<body.length;i++){
          console.log('hi i am here5');
            if(desiredInfo === 'Media' || desiredInfo === 'media'){
              console.log('hi i am here2');
              if(body[i].Name.includes('CLM') || body[i].Name.includes('Media')){
                console.log('hi i am here2');
                alexaAnnounce = alexaAnnounce+body[i].Alert_Text_vod__c+' .The Priority of the alert is '+body[i].Priority_vod__c+' .It was activated on '+new Date(body[i].Activation_Date_vod__c).toUTCString().split(' ').slice(0, 4).join(' ')+' at '+format_time(body[i].Activation_Date_vod__c)+' and will be expired on '+new Date(body[i].Expiration_Date_vod__c).toUTCString().split(' ').slice(0, 4).join(' ')+' at '+format_time(body[i].Expiration_Date_vod__c);
              }
            }else if(desiredInfo === 'AOC' || desiredInfo === 'aoc'){
              console.log('hi i am here4');
              if(body[i].Name.includes('AOC') || body[i].Name.includes('Content Acknowledgement')){
                alexaAnnounce = alexaAnnounce+body[i].Alert_Text_vod__c+' .The Priority of the alert is '+body[i].Priority_vod__c+' .It was activated on '+new Date(body[i].Activation_Date_vod__c).toUTCString().split(' ').slice(0, 4).join(' ')+' at '+format_time(body[i].Activation_Date_vod__c)+' and will be expired on '+new Date(body[i].Expiration_Date_vod__c).toUTCString().split(' ').slice(0, 4).join(' ')+' at '+format_time(body[i].Expiration_Date_vod__c);
              }
            }
          }
        }
        self.emit(':ask', alexaAnnounce);
      });
    },

    'TimeOffTerritoryCreation': function () {
      if (this.event.request.dialogState !== "COMPLETED") {
          // this.emit(":delegate", updatedIntent);
          console.log('not completed');
          console.log('reason '+ this.event.request.intent.slots.reason.value);
          console.log('dateOff '+ this.event.request.intent.slots.date.value);
          console.log('numberOfDays '+ this.event.request.intent.slots.numberOfDays.value);
          this.emit(":delegate");
      }else{
        var self = this;
        var alexaAnnounce = "I have created a Time Off Territory for you";
        console.log("reasons");
        //var reason = this.event.request.intent.slots.TimeOffTerritoryCreation.days;
        var options = { method: 'POST',
          url: 'https://cs52.salesforce.com/services/apexrest/timeOffTerritoryCreation/',
          headers:
            { 'postman-token': '2ba0f30e-efab-6c61-2a58-34f1f7894739',
              'cache-control': 'no-cache',
              'content-type': 'application/json',
              authorization: 'OAuth '+accessToken
            },
          body: {"userName" : "aditya.sridhara.rao@accenture.dev.lsassets",
                 "reason": this.event.request.intent.slots.reason.value,
                 "dateOff": this.event.request.intent.slots.date.value,
                 "numberOfDays": this.event.request.intent.slots.numberOfDays.value
          },
          json: true
        };

        request(options, function (error, response, body) {
          if (error) throw new Error(error);

          console.log(body);
          self.emit(':ask', alexaAnnounce);
        });
      }
    },

    'InteractionCreation': function () {
      var self = this;
      var accountNameSlot = this.event.request.intent.slots.accountName.value;
      var dateOfInteractionSlot = this.event.request.intent.slots.dateOfInteraction.value;
      var productsSlot = this.event.request.intent.slots.product.value;
      //var numberOfProductsSlot = this.event.request.intent.slots.numberOfProducts.value;
      var products = [];
      var alexaAnnounce = productsSlot+" is not aligned to you.";
    //  var alexaAnnounce="";

      if (this.event.request.dialogState !== "COMPLETED") {
          // this.emit(":delegate", updatedIntent);
          //this.emit(":delegate");
          if(!(accountNameSlot) || !(dateOfInteractionSlot)){
            this.emit(":delegate");
          }

          if((accountNameSlot) && (dateOfInteractionSlot) && !productsSlot){
            var options = { method: 'POST',
              url: 'https://cs52.salesforce.com/services/apexrest/interactionCreation/',
              headers:
                { 'postman-token': '828a258b-329b-1658-8f00-5d1ac77dac5d',
                  'cache-control': 'no-cache',
                  'content-type': 'application/json',
                  authorization: 'OAuth '+accessToken
                },
              body:
                { "userName" : "aditya.sridhara.rao@accenture.dev.lsassets",
                  "accountName": accountNameSlot,
                  "dateOfInteraction": dateOfInteractionSlot
                },
              json: true
            };

            request(options, function (error, response, body) {
              if (error) throw new Error(error);

              console.log(body);
              //body=JSON.parse(body);
              //console.log("id body "+ body);
              interactionId = body;
              console.log("id body1 "+ interactionId);
            //  self.emit(':ask', alexaAnnounce);
            });
          }

          this.emit(":delegate");

          /*if (!numberOfProductsSlot) {
            this.emit(":delegate");
          }

          for(var i=0; i<numberOfProductsSlot;i++){
            products.push(productsSlot);

            if(i<(numberOfProductsSlot-1)){
              this.emit(":delegate");
            }
          }*/

      }else{
        var options = { method: 'POST',
                        url: 'https://cs52.salesforce.com/services/apexrest/getUserProducts/',
                        headers:
                          { 'postman-token': '0bb17578-e914-cd45-d9f4-e90d472592ca',
                            'cache-control': 'no-cache',
                            authorization: 'OAuth '+accessToken,
                            'content-type': 'application/json' },
                        body: { userName: 'aditya.sridhara.rao@accenture.dev.lsassets' },
                        json: true
                      };

        request(options, function (error, response, body) {
          if (error) throw new Error(error);

          console.log(body);
          body=JSON.parse(body);
          if(!body.length){
            console.log('hi i am here1');
            alexaAnnounce = 'There are no products assigned to you at present. Therefore you cannot save an interaction with product';
          }else{
            for(var i=0;i<body.length;i++){
            console.log('hi i am here5 ' + body[i].Product_vod__r.Name);
            console.log('hi i am here6 ' + productsSlot);
              if(body[i].Product_vod__r.Name.toLowerCase() === productsSlot.toLowerCase()){
                console.log("here12 "+ body[i].Product_vod__r.Name);
                console.log("here123 "+ productsSlot);
                console.log("here1234 "+ interactionId);

                alexaAnnounce = 'Interaction has been saved with '+productsSlot+' as the detailed product';
                var options = {
                  method: 'PATCH',
                                url: 'https://cs52.salesforce.com/services/apexrest/interactionCreation/',
                  headers:
                    { 'postman-token': 'cd2910c2-0e53-b175-46b6-aa0274563372',
                      'cache-control': 'no-cache',
                      authorization: 'OAuth '+accessToken,
                      'content-type': 'application/json'
                    },
                    body: { product: body[i].Product_vod__r.Name,
                            interactionId: interactionId
                          },
                    json: true
                };

                request(options, function (error, response, body) {
                    if (error) throw new Error(error);

                    console.log(body);

                  });
                  break;
              }
            }
          }
          self.emit(':ask', alexaAnnounce);
        });
      }
    },

    'TimeOffTerritoryStatus': function(){
      if (this.event.request.dialogState === "STARTED") {
        var updatedIntent = this.event.request.intent;
        this.emit(":delegate",updatedIntent);
      }
      else if (this.event.request.dialogState !== "COMPLETED") {
          // this.emit(":delegate", updatedIntent);
          this.emit(":delegate",updatedIntent);
      }else {
      var self =this;
      var alexaAnnounce = "";
      var options = {
      method: 'POST',
      url: 'https://cs52.salesforce.com/services/apexrest/timeOffTerritoryCreation/',
      headers:
       { 'postman-token': '9df73c47-51da-1d3b-516e-1cebe72b29c6',
         'cache-control': 'no-cache',
          authorization: 'OAuth '+accessToken,
         'content-type': 'application/json' },
      body:
       { userName: 'aditya.sridhara.rao@accenture.dev.lsassets',
         dateForStatus: this.event.request.intent.slots.date.value },
         json: true };

      request(options, function (error, response, body) {
        if (error) throw new Error(error);

        body = JSON.parse(body);
        console.log(body);

        if(!body.length){
          console.log('body as null');
          alexaAnnounce = 'There is no Time Off Territory Record for the given date.';
        }else{
          alexaAnnounce = 'Status of your Time off Territory is'+body;
        }

        self.emit(':ask', alexaAnnounce);
      });
    }
    },

    'AMAZON.HelpIntent': function () {
        const speechOutput = HELP_MESSAGE;
        const reprompt = HELP_REPROMPT;

        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },
    'AMAZON.CancelIntent': function () {
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
    'AMAZON.StopIntent': function () {
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
};

function format_time(dateTimeString) {
// formats a javascript Date object into a 12h AM/PM time string
console.log('aisa nhi h, yaha aaya h');
var date_obj = new Date(dateTimeString);
var hour = date_obj.getHours();
var minute = date_obj.getMinutes();
var amPM = (hour > 11) ? "pm" : "am";
if(hour > 12) {
  hour -= 12;
} else if(hour == 0) {
  hour = "12";
}
if(minute < 10) {
  minute = "0" + minute;
}
console.log(hour + ":" + minute + amPM);
return hour + ":" + minute + amPM;
}

function isFirstCall(){
  //var firstCall = 'First Time';
  if(firstCall === 'true'){
    firstCall = 'false';
  }
  //return firstCall;
}

exports.handler = function (event, context, callback) {
    const alexa = Alexa.handler(event, context, callback);
    alexa.APP_ID = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};
